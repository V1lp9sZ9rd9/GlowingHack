@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.entity;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;