package net.minecraft.client.gui.spectator;

public interface ISpectatorMenuRecipient
{
    void onSpectatorMenuClosed(SpectatorMenu p_175257_1_);
}
