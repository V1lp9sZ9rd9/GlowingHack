package net.minecraft.client.gui.recipebook;

public interface IRecipeShownListener
{
    void func_192043_J_();
}
